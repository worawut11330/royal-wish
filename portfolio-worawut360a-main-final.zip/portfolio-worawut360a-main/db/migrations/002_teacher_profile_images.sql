-- เพิ่มแกลเลอรีภาพประวัติครูผู้รับการประเมิน
-- ใช้ได้กับฐานข้อมูลเดิมที่มี teacher_profile อยู่แล้ว
CREATE TABLE IF NOT EXISTS teacher_profile_images (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  source      TEXT CHECK(source IN ('drive','static')) NOT NULL DEFAULT 'drive',
  ref         TEXT NOT NULL,
  caption     TEXT NOT NULL DEFAULT '',
  width       INTEGER NOT NULL DEFAULT 0,
  height      INTEGER NOT NULL DEFAULT 0,
  sort_order  INTEGER NOT NULL DEFAULT 0,
  created_at  TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_tpi_sort
  ON teacher_profile_images (sort_order, id);
