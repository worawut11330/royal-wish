import 'server-only'

import { db, all, now } from './db'
import type { MediaSource } from './media'

export interface ProfileImage {
  id: number
  source: MediaSource
  ref: string
  caption: string
  width: number
  height: number
  sort_order: number
}

export interface ProfileImageInput {
  source?: unknown
  ref?: unknown
  caption?: unknown
}

let ensured = false

/** รองรับฐานข้อมูลเดิมที่สร้างก่อนเพิ่มระบบภาพประวัติครู */
export async function ensureProfileImagesTable() {
  if (ensured) return
  await db.execute({
    sql: `CREATE TABLE IF NOT EXISTS teacher_profile_images (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      source TEXT CHECK(source IN ('drive','static')) NOT NULL DEFAULT 'drive',
      ref TEXT NOT NULL,
      caption TEXT NOT NULL DEFAULT '',
      width INTEGER NOT NULL DEFAULT 0,
      height INTEGER NOT NULL DEFAULT 0,
      sort_order INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    )`,
    args: [],
  })
  await db.execute({
    sql: 'CREATE INDEX IF NOT EXISTS idx_tpi_sort ON teacher_profile_images (sort_order, id)',
    args: [],
  })
  ensured = true
}

export async function getProfileImages(): Promise<ProfileImage[]> {
  try {
    await ensureProfileImagesTable()
    return await all<ProfileImage>(
      `SELECT id, source, ref, caption, width, height, sort_order
       FROM teacher_profile_images
       ORDER BY sort_order, id`,
    )
  } catch {
    // ถ้าฐานข้อมูลยังไม่พร้อม หน้าเว็บประวัติครูไม่ควรล่มทั้งหน้า
    return []
  }
}

function parseProfileImages(raw: string): ProfileImageInput[] {
  let data: unknown
  try { data = JSON.parse(raw || '[]') } catch { return [] }
  if (!Array.isArray(data)) return []

  return data.flatMap((r: ProfileImageInput) => {
    const ref = String(r.ref ?? '').trim()
    if (!ref || ref.length > 200) return []
    return [{
      source: r.source === 'static' ? 'static' : 'drive',
      ref,
      caption: String(r.caption ?? '').slice(0, 255),
    }]
  }).slice(0, 60)
}

export async function saveProfileImages(raw: string) {
  await ensureProfileImagesTable()
  const images = parseProfileImages(raw)
  const t = now()

  await db.execute({ sql: 'DELETE FROM teacher_profile_images', args: [] })

  for (const [i, image] of images.entries()) {
    await db.execute({
      sql: `INSERT INTO teacher_profile_images
              (source, ref, caption, sort_order, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?)`,
      args: [image.source, image.ref, image.caption, i, t, t],
    })
  }
}

