'use client'

import { useState } from 'react'
import { ImageSection, type ImageRow } from './MediaEditor'
import SectionHead from './ModalSectionHead'
import type { ProfileImage } from '@/lib/profile-images'

export default function ProfileGallerySection({ initial }: { initial: ProfileImage[] }) {
  const [rows, setRows] = useState<ImageRow[]>(
    initial.map((r) => ({
      id: r.id,
      source: r.source,
      ref: r.ref,
      caption: r.caption,
    })),
  )

  return (
    <>
      <input type="hidden" name="profile_images" value={JSON.stringify(rows)} />

      <section className="mt-4 bg-white rounded-[1.6rem] p-6 md:p-7 shadow-soft border border-[color:var(--border)]">
        <SectionHead icon="📸" bg="bg-sky-soft">ภาพประวัติครูผู้รับการประเมิน</SectionHead>

        <div className="mt-3 mb-4 rounded-2xl bg-primary-soft/60 p-4">
          <p className="text-[13px] font-bold">📸 ภาพกิจกรรม / ภาพประวัติ</p>
          <p className="text-[11.5px] text-ink-muted mt-1">
            เพิ่มรูปจาก Google Drive ได้หลายรูป · กดดูตัวอย่างก่อนบันทึก · ลากที่ ⠿ เพื่อกำหนดลำดับการแสดง
          </p>
        </div>

        <ImageSection
          rows={rows}
          onChange={setRows}
          label="+ เพิ่มรูปภาพ"
          hint="วางลิงก์แชร์จาก Google Drive · ตั้งค่าไฟล์เป็น “ทุกคนที่มีลิงก์” ก่อน"
        />
      </section>
    </>
  )
}
